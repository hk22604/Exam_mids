import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Subjects App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomeScreen(),
    );
  }
}

class Subject {
  final String name;
  final String teacher;
  final int creditHours;

  Subject({required this.name, required this.teacher, required this.creditHours});
}

class HomeScreen extends StatelessWidget {
  final List<Subject> enrolledSubjects = [
    Subject(name: "Mathematics", teacher: "Dr. Smith", creditHours: 3),
    Subject(name: "Physics", teacher: "Prof. Johnson", creditHours: 4),
    Subject(name: "Chemistry", teacher: "Dr. Lee", creditHours: 3),
    Subject(name: "English Literature", teacher: "Mrs. Davis", creditHours: 2),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('My Subjects'),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.blue,
              ),
              child: Text(
                'Navigation Menu',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                ),
              ),
            ),
            ListTile(
              leading: Icon(Icons.home),
              title: Text('Home'),
              onTap: () {
                Navigator.pop(context);
              },
            ),
            // Add more drawer items here if needed
          ],
        ),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Image section
          Container(
            width: double.infinity,
            height: 200,
            child: Image.network(
              'https://flutter.dev/assets/homepage/carousel/slide_1-bg-opaque-1a6e992b57407e48b1b6163c095fdf7b7f87e815a4f9f84db29c7166010eaba6.jpg',
              fit: BoxFit.cover,
            ),
          ),
          SizedBox(height: 16),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Text(
              'Enrolled Subjects',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ),
          SizedBox(height: 8),
          Expanded(
            child: ListView.builder(
              itemCount: enrolledSubjects.length,
              itemBuilder: (context, index) {
                final subject = enrolledSubjects[index];
                return Card(
                  margin: EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                  child: ListTile(
                    title: Text(subject.name),
                    subtitle: Text('Teacher: ${subject.teacher}'),
                    trailing: Text('${subject.creditHours} credit hrs'),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
