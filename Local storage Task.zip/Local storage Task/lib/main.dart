import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SQLite Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.light(primary: Colors.teal),
      ),
      home: NameSaverScreen(),
    );
  }
}

class NameSaverScreen extends StatefulWidget {
  @override
  _NameSaverScreenState createState() => _NameSaverScreenState();
}

class _NameSaverScreenState extends State<NameSaverScreen> {
  final TextEditingController _controller = TextEditingController();
  late Database _database;
  List<Map<String, dynamic>> _names = [];

  @override
  void initState() {
    super.initState();
    _initDatabase();
  }

  Future<void> _initDatabase() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'names.db');

    _database = await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute(
          'CREATE TABLE names(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT)',
        );
      },
    );

    _loadNames();
  }

  Future<void> _saveName(String name) async {
    if (name.trim().isEmpty) return;

    await _database.insert(
      'names',
      {'name': name},
      conflictAlgorithm: ConflictAlgorithm.ignore,
    );

    _controller.clear();
    _loadNames();
  }

  Future<void> _loadNames() async {
    final List<Map<String, dynamic>> maps = await _database.query('names');

    setState(() {
      _names = maps;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Save Names Locally'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _controller,
              decoration: InputDecoration(
                labelText: 'Enter Name',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: () => _saveName(_controller.text),
              child: Text('Save'),
            ),
            Divider(height: 30),
            Expanded(
              child: _names.isEmpty
                  ? Center(child: Text('No names saved yet.'))
                  : SingleChildScrollView(
                scrollDirection: Axis.vertical,
                child: DataTable(
                  columns: [
                    DataColumn(label: Text('ID')),
                    DataColumn(label: Text('Name')),
                  ],
                  rows: _names.map((entry) {
                    return DataRow(cells: [
                      DataCell(Text(entry['id'].toString())),
                      DataCell(Text(entry['name'])),
                    ]);
                  }).toList(),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
